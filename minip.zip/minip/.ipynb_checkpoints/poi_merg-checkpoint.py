

def FINAL(Type,Duration,Budget,TYPE,Ques):
  print(Type,Duration,Budget,TYPE,Ques)

  import pandas as pd
  import numpy as np
  from  itertools import chain
  import numpy as np
  import re
  import math
  from math import cos, sin, atan2, sqrt
  import folium
  from folium import plugins
  #from IPython.display import Image
  import plotly.express as px
  import datetime
  from datetime import timedelta
  from datetime import datetime
  from plotly.express import timeline
  import pickle
  def dict_index_key(val_to_find,DICT):
    for k,v in DICT.items():
      if (v==val_to_find):
        return k
  def next_min(lis):
    m = [x*(-1) for x in lis]
  def get_pid_from_index(no):
    return 'POI'+str(no+1)
  def get_place(POI):
    c = jaipur_poi_df.loc[POI,'POIs']
    return c


  jaipur_poi_df = pd.read_csv('data/jaipur-poi.csv')
  dist_only_matrix_df = pd.read_csv('data/dist_only_matrix.csv')


  jaipur_poi_df.set_index('PID',inplace=True)
  jaipur_poi_df.head()
  dist_only_matrix_df.set_index('PID',inplace=True)
  dist_only_matrix_df.head(10)
  def extract(st):
    if (len(st)==8):
      return (st[2:6])
    else:
      return (st[2:7])
  def poi_finddist(poi1,poi2): 

    # extracting indices
    POI1=poi1.upper()
    POI2=poi2.upper()
    for i in jaipur_poi_df.iloc[:,0]:

      # to get name of place from pid (Ex: 'POI70')
      P1 = extract(np.array_str(jaipur_poi_df[jaipur_poi_df['POIs']==POI1].index.values))
      P2 = extract(np.array_str(jaipur_poi_df[jaipur_poi_df['POIs']==POI2].index.values))

      # indices
      x=int(P1[3:])-1
      y=int(P2[3:])-1
      if(x>=y):
        return dist_only_matrix_df.iloc[x,y]
      else:
        return dist_only_matrix_df.iloc[y,x]
  vac_type = {'Adventure and Outdoors':['Adventure'],'Spiritual':['Religious'],'Relaxing':['Scenic'],'City Life':['Food and Drinks','Shopping','Shows and Concerts'],'Cultural':['Local Experiences','History and Culture','Museum']}
  vac_type
  ## Main Input
  #(Run for changed Input)
  # Type = []

  # print("Choose your vacation type (priority-wise): \nAdventure and Outdoors\nCity Life\nCultural\nRelaxing\nSpiritual\n\nTo Stop, Enter 'N' \n\n ")

  # for i in range(0,5):
  #   j=i+1
  #   k = input('Enter Priority no. %d: '%j)
  #   if (k!='N'):
  #     Type.append(k)
  #   else:
  #     break

  # L=len(Type)

  # try:
  #   Duration = int(input('\n Enter number of days for the trip: '))
  # except:
  #   Duration = int(input('\n Enter a number: '))

  # try:
  #   Budget = int(input('\n Enter a rough budget for the trip: '))
  # except:
  #   Budget = int(input('\n Enter a number: '))

  # TYPE = input('\n Choose one:\nFamily\nFriends\nIndividual\n\n')

  # Ques = input('\n Is covering maximum places a priority (y/n)? ')

  # Algorithms
  ## Info
  def user_info():
    type_print = []
    type_print.append(str('User type choices: '))

    for i in range(0,len(Type)):
      type_print.append(str(str(i+1) +'. '+ Type[i]))

    type_print.append(str('No. of days: '+ str(Duration)))
    type_print.append(str('Budget: '+ str(Budget)))
    type_print.append(str('No. of POIs: '+str(no_of_pois)))
    type_print.append(str('Type: '+TYPE))
    if (Ques == 'y'):
      type_print.append(str('Covering maximum places is a priority.'))
    else:
      type_print.append(str('Covering maximum places is NOT a priority.'))
      #type_print.append(str('Suggested Hotel/Accomodation: '+nearest_hotel))
    type_print.append(str(nearest_hotel))
    
    return type_print

  
  ## User Matrix
  #(Run for changed input)
  vac_hm_df = pd.read_csv('data/vac_hm.csv')
  vac_hm_df.set_index('Unnamed: 0',inplace=True)
  vac_hm_df.head(3)
  Type
  user_matrix = {'Shows and Concerts':0,'Scenic':0,'Local Experiences':0,'Religious':0,'History and Culture':0, 'Museum':0,'Food and Drinks':0,'Adventure':0,'Shopping':0}
  vac_type
  # Creating User 1d array of vacation type according to input choices filled

  for i in range(0,len(Type)):
    pvalue = 5-i
    for j in vac_type[Type[i]]:
      if (j == 'History and Culture'):
        user_matrix[j] = pvalue+(0.075*pvalue)
      elif (j == 'Local Experiences'):
        user_matrix[j] = pvalue+(0.055*pvalue)
      else:
        user_matrix[j] = pvalue
  user_matrix
  val = list(user_matrix.values())
  typ = list(user_matrix.keys()) # to be used in cosine similarity
  #print(val)
  #print(typ)
  TEMP=[typ,val]
  user_df = pd.DataFrame(TEMP,columns=typ)
  user_df.drop(axis=0,index=0,inplace=True)
  user_df
  ## Deciding Places by Priority (Cosine Similarity)
  #(Run for changed Input)
  # J_priority_mapping.csv
  #uploaded = files.upload()
  J_priority_df = pd.read_csv('data/J_priority_mapping.csv')
  J_priority_df.set_index('PID',inplace=True)
  ### Formula
  def cen_cos_h(lis): # takes 1 returns 1
    lol =[]
        
    avg =sum(lis)/9

    for x in lis:
        lol.append(x-avg)
    return lol

  def cencos_formula_h(LIS1,LIS2):

    lis1 = cen_cos_h(LIS1)
    lis2 = cen_cos_h(LIS2)

    i=0

    prod_lis = []
    while (i<len(lis1)):
      if(lis1[i]!=0 and lis2[i]!=0):
        product = lis1[i]*lis2[i]
        prod_lis.append(product)

      i=i+1

    sq_lis1 = [(x)**2 for x in lis1]
    sq_lis2 = [(x)**2 for x in lis2]

    sum_sq_lis1 = sum(sq_lis1)
    sum_sq_lis2 = sum(sq_lis2)

    sqrt_lis1=math.sqrt(sum_sq_lis1)
    sqrt_lis2=math.sqrt(sum_sq_lis2)


    num = sum(prod_lis)
    den = sqrt_lis1*sqrt_lis2

    try:
      cos = num/den
    except:
      cos = 0

    if (den==0):
      cos = 'lalala'




  


    return cos

  print('CHECK1')
  ### Cosine similarity
  #(Run for changed inputs)
  J_priority_df.head()
  cos_sim_list_h = []
  cos_sim_dict_h = {}
  for i in range(0,len(J_priority_df.iloc[:,1:])):

    x = list(J_priority_df.iloc[i,1:]) # one row in the POI priority df
    y = val # user
    
    
    result = cencos_formula_h(x,y)

    cos_sim_list_h.append(result) 
    cos_sim_dict_h[i] = result
  ### Deciding Places
  #(Run this for changed inputs)
  import matplotlib.pyplot as plt
  c=0
  selected={} # vacation cosine similarity is greater than 0
  for k,v in cos_sim_dict_h.items():
    if(v>0):
      c=c+1
      selected[k]=v
  no_of_pois = c
  #print(no_of_pois)
  sorted_selected1 = dict(sorted(selected.items(), key=lambda item: item[1],reverse=True))
  #print(sorted_selected1) #DICTIONARY
  sorted_selected = {}
  for k,v in sorted_selected1.items():
    sorted_selected[k] = v
  x = no_of_pois/Duration

  if (Ques=='y'):
    while (x>6):
      sorted_selected.popitem()
      no_of_pois = len(sorted_selected)
      x=no_of_pois/Duration 

  elif (Ques=='n'):
    while (x>3):
      sorted_selected.popitem()
      no_of_pois = len(sorted_selected)
      x=no_of_pois/Duration 

      
  #print('Final no.: ',no_of_pois)
  # for k,v in sorted_selected.items(): 
  #   p = k+1
  #   pid = 'POI'+str(p)
  #   print(jaipur_poi_df.loc[pid,'POIs'])
  #   print(list(J_priority_df.loc[pid,'Shows and Concerts':])) # range -  " 'Shows and Concerts': "
  #   print(val)
  #   print('\n\n')
  len(sorted_selected)
  # creating selected df
  ll= []
  for k,v in sorted_selected.items():
    l = []
    l.append(k)
    l.append(v)
    ll.append(l)

  sorted_selected_df = pd.DataFrame(ll)
  sorted_selected_df.set_index(0,inplace=True)
  sorted_selected_df.columns = ['sorted priority']


  l1 = []
  l2 = []
  for i in sorted_selected_df.iterrows():
    ind = i[0]
    pid = 'POI'+str(ind+1)
    l1.append(pid)
    l2.append(jaipur_poi_df.loc[pid,'POIs'])

  sorted_selected_df['PID'] = l1
  sorted_selected_df['POIs'] = l2 
  (sorted_selected_df)
  sorted_selected_df.to_csv('data/sorted_selected_df.csv')
  ### 


  ## Get Center Coordinates for initially Selected (based on vacation type input) POIs
  #(run for new inputs)
  #( result )
  #!pip install gmplot
  #uploaded = files.upload()
  lat_lng_df = pd.read_csv('data/lat_lng.csv')
  lat_lng_df.set_index(jaipur_poi_df.index,inplace=True)
  lat_lng_df.drop(columns=['Unnamed: 0'],inplace=True)
  selected_coord = {}
  for i in range(0,no_of_pois):
    selected_coord[list(sorted_selected_df['PID'])[i]] = lat_lng_df.loc[list(sorted_selected_df['PID'])[i],'Lat,Lng']
  selected_coord

  coord_pairs = []
  for k,v in selected_coord.items():
    a = list(map(float,v.split(',')))
    coord_pairs.append(a)
  coord_pairs
  def center(coord_pairs):
    l=len(coord_pairs)
    sum_i=0.0
    sum_j=0.0
    for i,j in coord_pairs:
      sum_i=sum_i+float(i)
      sum_j=sum_j+float(j)

    LAT = sum_i/l
    LONG = sum_j/l

    return [LAT,LONG]
  result = center(coord_pairs)
  result
  