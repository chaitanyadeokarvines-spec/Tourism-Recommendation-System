import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

np.random.seed(0)
x=np.random.randn(100,2)
y=np.random.randint(0,2,size=100)

model=LogisticRegression.fit(x,y)
accuracy=accuracy_score(y,model.predict(x))
print("Accuracy:",accuracy)