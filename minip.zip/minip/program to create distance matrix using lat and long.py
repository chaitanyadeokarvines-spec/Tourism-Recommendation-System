import pandas as pd
import numpy as np
from math import radians, sin, cos, sqrt, atan2

# Function to calculate distance between two points using Haversine formula
def haversine_distance(lat1, lon1, lat2, lon2):
    # Radius of the Earth in km
    R = 6371.0
    
    # Convert latitude and longitude from degrees to radians
    lat1_rad = radians(lat1)
    lon1_rad = radians(lon1)
    lat2_rad = radians(lat2)
    lon2_rad = radians(lon2)
    
    # Calculate the change in coordinates
    dlon = lon2_rad - lon1_rad
    dlat = lat2_rad - lat1_rad
    
    # Calculate the distance using Haversine formula
    a = sin(dlat / 2)**2 + cos(lat1_rad) * cos(lat2_rad) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = R * c
    
    return distance

# Read CSV file containing latitude and longitude coordinates
places_df = pd.read_csv('Places.csv')

# Initialize distance matrix
num_places = len(places_df)
distance_matrix = np.zeros((num_places, num_places))

# Calculate distances and populate distance matrix
for i in range(num_places):
    for j in range(num_places):
        lat1, lon1 = places_df.loc[i, 'Latitude'], places_df.loc[i, 'Longitude']
        lat2, lon2 = places_df.loc[j, 'Latitude'], places_df.loc[j, 'Longitude']
        distance_matrix[i, j] = haversine_distance(lat1, lon1, lat2, lon2)

# Convert distance matrix to DataFrame
distance_matrix_df = pd.DataFrame(distance_matrix, index=places_df.index, columns=places_df.index)

# Write distance matrix to CSV file
distance_matrix_df.to_csv('dist_only_matrix.csv')

print("Distance matrix has been created and saved to 'dist_only_matrix.csv'.")
