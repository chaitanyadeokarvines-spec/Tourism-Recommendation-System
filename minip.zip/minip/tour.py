import streamlit as st
import pickle
from poi_trialmerged import FINAL
import pandas as pd
import streamlit.components.v1 as components

# Define custom CSS style
custom_style = """
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .hotel-bold {
			    font-weight: 600;
			  }

			  .hotel-font {
			    font-size: 20px;
          background-color: #e6f9ff;
			  }


        .title {
            font-size: 36px;
            font-weight: bold;
            color: #007bff;
            margin-bottom: 30px;
        }

        .subtitle {
            font-size: 24px;
            font-weight: bold;
            color: #666;
            margin-top: 20px;
            margin-bottom: 10px;
        }

        .btn-primary {
            background-color: #007bff;
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .slider-container {
            margin-bottom: 20px;
        }

        .slider-label {
            font-size: 18px;
            color: #666;
            margin-bottom: 10px;
        }

        .slider-value {
            font-size: 16px;
            color: #007bff;
        }

        .stSlider {
            background-color: #007bff;
            border-radius: 5px;
        }

        .stSlider>div {
            background-color: #0056b3 !important;
        
        .vacation-type-dropdown .selectize-input {
            border: 2px solid #007bff;
            border-radius: 5px;
            color: #333;
            font-weight: bold;
        }
        
        
        .travel-with-dropdown .selectize-input {
            border: 2px solid #007bff;
            border-radius: 5px;
            color: #333;
            font-weight: bold;
        }
        }
    </style>
"""

# Apply custom CSS style
st.markdown(custom_style, unsafe_allow_html=True)

# Streamlit components
st.image('./data/Cover-Img.jpg')
st.title(' Tourism Recommendation System ')

# Function to load pickled data
def load_data():
    try:
        with open('data/user_data.pickle', 'rb') as handle:
            return pickle.load(handle)
    except FileNotFoundError:
        return []

# Function to save data using Pickle
def save_data(data):
    with open('data/user_data.pickle', 'wb') as handle:
        pickle.dump(data, handle)


# Main function
def main():
    data = load_data()
    
    vacation_types = ['Adventure and Outdoors', 'Spiritual', 'City Life', 'Cultural', 'Relaxing']
    travel_with_options = ['Family', 'Friends', 'Individual']

    selected_vacation_types = st.multiselect("Select vacation types:", vacation_types)
    duration = st.slider("Select duration (days):", min_value=1, max_value=40, step=1, value=7)
    duration_text = st.empty()
    duration_text.markdown(f'<p class="slider-value">{duration} days</p>', unsafe_allow_html=True)
    
    budget = st.slider("Select budget (INR):", min_value=200, max_value=150000, step=500, value=5000)
    budget_text = st.empty()
    budget_text.markdown(f'<p class="slider-value">₹{budget}</p>', unsafe_allow_html=True)
    
    travel_with = st.selectbox("Who are you traveling with?", travel_with_options)

    if st.button("Recommend"):
        try:
            result = FINAL(selected_vacation_types, duration, budget, travel_with)
        except:
            st.error("An error occurred while generating recommendations. Please check your inputs and try again.")
            return
        
        data.append({"Selected Types": selected_vacation_types, "Duration": duration, "Budget": budget, "Travel With": travel_with})
        pd.DataFrame(data).to_csv('data/FinalData.csv')

        output = result[0]
        info = result[1]

        st.subheader('Your Inputs')
        st.write('{}'.format(info[0]))
        
        for i in range(1, len(info)-5):
            try: 
                st.write('{}'.format(info[i]))
            except:
                continue
        
        for i in range(4, len(info)-2):
            try: 
                st.write('{}'.format(info[i]))
            except:
                continue
        
        st.write('{}'.format(info[-2]))
        
        st.header('Suggested Itinerary')
        st.markdown('<p class="hotel-font"><span class="hotel-bold">Suggested Places:</span> {}<p>'.format(info[-1]),unsafe_allow_html=True)
        st.write(' ')
        for i in range(0,len(output)):
          st.write('{}'.format(output[i]))

if __name__ == '__main__':
    main()
